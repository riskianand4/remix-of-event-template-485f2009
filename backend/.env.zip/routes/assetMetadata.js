const express = require("express");
const router = express.Router();
const Asset = require("../models/Asset");
const { auth } = require("../middleware/auth");

// GET /api/assets/metadata/categories - Get unique asset categories
router.get("/metadata/categories", auth, async (req, res) => {
  try {
    const categories = await Asset.distinct("category");
    
    // Filter out null/undefined and sort alphabetically
    const validCategories = categories
      .filter(cat => cat && cat.trim() !== '')
      .sort((a, b) => a.localeCompare(b));
    
    res.json({
      success: true,
      data: validCategories
    });
  } catch (error) {
    console.error("Error fetching asset categories:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch asset categories",
      error: error.message
    });
  }
});

module.exports = router;
